public class Obserwator1 implements Obserwator{
    @Override
    public void update(String stan) {
        System.out.println(stan);
    }
}
