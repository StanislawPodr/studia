public interface Obserwator {
public void update(String stan) throws Exception;
}
