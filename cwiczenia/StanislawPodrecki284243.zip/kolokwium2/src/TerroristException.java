public class TerroristException extends Exception{
    
}
