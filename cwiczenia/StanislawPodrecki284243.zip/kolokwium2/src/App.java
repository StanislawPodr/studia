import javax.swing.*;

//domyślnie pliki.txt są w katalogu src
public class App {
    public static void main(String[] args) throws Exception {
       Gui.createGui();
    }
}
