import uczelnia.Osoba;
import java.util.List;
import java.util.Scanner;

public interface AddPracownikStrategy {
    public void add(List<Osoba> osoby, Scanner scanner);
}
